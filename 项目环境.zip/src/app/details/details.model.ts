export class Details {
  userId: string;
  bookId: string;
  authorName: string;
  bookName: string;
  educationName: string;
  quantity: number;
}
